# MEMORY.md - Long-Term Memory

## Stable Facts

- Human should be addressed as **Boss**.
- Primary workspace is `~/Desktop/OpenClaw Bot`.
- Preferred language is Chinese.

## Operating Priorities

- Keep OpenClaw gateway + ClawBot stack healthy and controllable from one native app.
- Minimize manual setup by persisting project-scoped settings.
- For investment workflows, run a profit-first strategy with strict risk guardrails.

## Decision Rules

- If daily/weekly profit targets are missed, immediately switch to recovery mode.
- Recovery mode means: diagnose loss drivers, retrain decision rules, reduce risk, re-validate, then resume.
- Service uptime and risk controls are hard constraints, not optional improvements.
